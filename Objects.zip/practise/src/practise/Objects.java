package practise;



public class Objects {
	int x=5;   //value in class is execueted using assigning a object.
	int y=10;  //multiple objects can be created and assigned.
	int z=x+y;
	
	                         //static can directly print value by calling the function.
	static void myfog() {
		System.out.println("Hello nrfm");
	}
	
	public void mycat() {   //In public need to create object using class name
		System.out.println("Hello foggy");
        int t=10;		
		System.out.println(t);
	}
	
	int s;               //constructor=create function using class name
	public Objects() {
		s=56;
	}
	public static void main(String[] args) {
		Objects on=new Objects();
		Objects to=new Objects();
		System.out.println(on.z);
		System.out.println(to.y);
		
		myfog();
		
		Objects ant=new Objects();
		ant.mycat();
		
		Objects bird=new Objects();
		System.out.println(bird.s);
		bird.s=30;                      //over ride
		System.out.println(bird.s);
	}
}
